@extends('layout.master')
@section('content')
    <div class="container">
<h2>Data Peminjam</h2>
<p>Halaman ini menampilkan data peminjam</p>
</div>
@endsection