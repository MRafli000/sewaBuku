<div id="home">
<h2>Home</h2>
<p>Selamat datang di Aplikasi Sewa Buku Rafli</p>
</div>