<?php
  echo 'Nama : Nama : Rafli <br> Nim : 43320118 <br> Alamat : Kota Bekasi <br> Hobi : Futsal';
?>