@extends('layout.master')
@section('content')
    <div class="container">
        <h2>Selamat Datang</h2>
    </div>
@endsection
