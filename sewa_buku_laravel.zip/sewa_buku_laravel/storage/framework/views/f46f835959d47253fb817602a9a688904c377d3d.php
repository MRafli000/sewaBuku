<?php if(Session::has('flash_message')): ?>
    <div class="alert-success <?php echo e(Session::has('penting')? 'alert-important' : ''); ?>">
        <?php echo e(Session::get('flash_message')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/_partial/flash_message.blade.php ENDPATH**/ ?>