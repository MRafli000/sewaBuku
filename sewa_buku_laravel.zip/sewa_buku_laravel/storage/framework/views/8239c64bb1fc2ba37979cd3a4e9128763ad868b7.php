
<?php $__env->startSection('content'); ?> 
    <div class="container">
        <h4>Data Buku</h4>
        <?php echo $__env->make('_partial/flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(Auth::check() && Auth::user()->level == 'admin'): ?>
        <p align="right"><a href="<?php echo e(route('buku.create')); ?>" class="btn btn-primary">Tambah Buku</a></p>
        <?php endif; ?>
        
        <table class="table table-striped">
            <thread>
                <tr>
                    <th>No</th>
                    <th>Kode Buku</th>
                    <th>Judul Buku</th>
                    <th>Jumlah Halaman</th>
                    <th>ISBN</th>
                    <th>Pengarang</th>
                    <th>Tahun Terbit</th>
                    <?php if(Auth::check() && Auth::user()->level == 'admin'): ?>
                    <th>Edit</th>
                    <th>Hapus</th>
                    <?php endif; ?>
                </tr>
            </thread>
            <tbody>
                <?php $__currentLoopData = $data_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($buku->id); ?></td>
                    <td><?php echo e($buku->kode_buku); ?></td>
                    <td><?php echo e($buku->judul_buku); ?></td>
                    <td><?php echo e($buku->jumlah_halaman); ?></td>
                    <td><?php echo e($buku->ISBN); ?></td>
                    <td><?php echo e($buku->pengarang); ?></td>
                    <td><?php echo e($buku->tahun_terbit); ?></td>
                    <?php if(Auth::check() && Auth::user()->level == 'admin'): ?>
                    <td><a href="<?php echo e(route('buku.edit', $buku->id)); ?>"  class="btn btn-warning btn-sm">Edit</a></td>
                    <td>
                        <form action="<?php echo e(route('buku.destroy', $buku->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-warning btn-sm" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="pull-left">
            <strong>
                Jumlah Buku : <?php echo e($jumlah_buku); ?>

            </strong>
            <p><?php echo e($data_buku->links()); ?> </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/buku/index.blade.php ENDPATH**/ ?>