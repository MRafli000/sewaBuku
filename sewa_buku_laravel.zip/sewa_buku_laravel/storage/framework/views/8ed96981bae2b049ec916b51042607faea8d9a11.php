
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Data Peminjam</h4>
        <p align="right"><a href="<?php echo e(route('peminjaman.create')); ?>" class="btn btn-primary">Tambah Data Peminjaman</a></p>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Transaksi</th>
                    <th>Nama Peminjam</th>
                    <th>Judul Buku</th>
                    <th>Tanggal Peminjaman</th>
                    <th>Tanggal Pengembalian</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data_peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($peminjaman->id); ?></td>
                    <td><?php echo e($peminjaman->kode_transaksi); ?></td>
                    <td><a href="<?php echo e(route('peminjaman.detail_peminjam', $peminjaman->data_peminjam['id'])); ?>"><?php echo e($peminjaman->data_peminjam['nama_peminjam']); ?></td>
                    <td><a href="<?php echo e(route('peminjaman.detail_buku', $peminjaman->data_buku['id'])); ?>"><?php echo e($peminjaman->data_buku['judul_buku']); ?></td>
                    <td></td>
                    <td><?php echo e($peminjaman->tgl_peminjaman); ?></td>
                    <td><?php echo e($peminjaman->tgl_pengembalian); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pull-left">
            <strong>
                Jumlah Peminjaman : <?php echo e($jumlah_peminjaman); ?>

            </strong>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/peminjaman/index.blade.php ENDPATH**/ ?>