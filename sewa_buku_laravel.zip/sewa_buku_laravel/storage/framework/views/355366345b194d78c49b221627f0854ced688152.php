<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Selamat Datang</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>