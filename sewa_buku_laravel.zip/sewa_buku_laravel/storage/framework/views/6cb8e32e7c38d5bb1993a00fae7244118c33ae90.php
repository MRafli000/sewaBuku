<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Sewa Buku</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php if(Auth::check() && Auth::user()): ?>
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('buku.index')); ?>">Data Buku</a>
        </li>
        <?php endif; ?>
        <?php if(Auth::check() && Auth::user()->level == 'admin'): ?>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('data_peminjam.index')); ?>">Data Peminjam</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('peminjaman.index')); ?>">Transaksi Peminjaman</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('user.index')); ?>">User</a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
          <a class="btn btn-danger btn-sm" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
          document.getElementById('logout-form').submit();"> <?php echo e(__('Logout')); ?></a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
      <div>
        <?php if(Auth::check()): ?>
          <b><?php echo e('Hai, '. Auth::user()->name); ?></b>
        <?php else: ?>
        <?php endif; ?>
      </div>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/layout/navbar.blade.php ENDPATH**/ ?>