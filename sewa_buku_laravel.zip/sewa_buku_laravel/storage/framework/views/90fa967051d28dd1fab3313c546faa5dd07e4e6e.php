<?php
  echo 'Nama : Nama : Rafli <br> Nim : 43320118 <br> Alamat : Kota Bekasi <br> Hobi : Futsal';
?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/biodata2.blade.php ENDPATH**/ ?>