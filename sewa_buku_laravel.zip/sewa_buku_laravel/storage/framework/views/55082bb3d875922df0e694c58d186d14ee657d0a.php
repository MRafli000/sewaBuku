
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Detail Buku</h4>
        <p>Kode Buku : <?php echo e($data_buku->kode_buku); ?></p>
        <p>Judul Buku : <?php echo e($data_buku->judul_buku); ?></p>
        <table class="table table-striped">
            <thead>
                <th>No</th>
                <th>Nama Peminjam</th>
            </thead>
            <tbody>
                <?php $i = 1 ?>
                <?php $__currentLoopData = $data_buku->data_peminjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($item->nama_peminjam); ?></td>
                </tr>
                <?php $i++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/peminjaman/detail_buku.blade.php ENDPATH**/ ?>