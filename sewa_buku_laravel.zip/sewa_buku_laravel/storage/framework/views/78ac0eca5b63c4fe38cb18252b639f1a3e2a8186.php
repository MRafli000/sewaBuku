
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Tambah Transaksi Peminjaman</h4>
        <form method="POST" action="<?php echo e(route('peminjaman.store')); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Kode Peminjaman</label>
                <input type="text" name="kode_transaksi" class="form-control">
                <input type="hidden" name="tgl_peminjaman" class="form-control" value="<?php echo e(date('Y-m-d')); ?>">
                <input type="hidden" name="tgl_pengembalian" class="form-control" value="<?php echo e(date('Y-m-d', strtotime('+15 day', strtotime(date('Y-m-d'))))); ?>">
            </div>
            <div class="form-group">
                <label form="">Nama Peminjam</label>
                <select name="id_peminjam" class="form-control">
                    <option value="">Pilih Nama Peminjam</option>
                        <?php $__currentLoopData = $list_data_peminjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>">
                        <?php echo e($value); ?>

                    </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label form="">Judul Buku</label>
                <select name="id_buku" class="form-control">
                    <option value="">Pilih Judul Buku</option>
                        <?php $__currentLoopData = $list_data_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>">
                        <?php echo e($value); ?>

                    </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <button type="submit">Simpan</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/peminjaman/create.blade.php ENDPATH**/ ?>