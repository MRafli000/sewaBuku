
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Data Peminjam</h4>
        <?php echo $__env->make('_partial/flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
        <p align="left"><a href="<?php echo e(route('data_peminjam.data_peminjam_pdf')); ?>" class="btn btn-primary">Download Data Peminjam</a></p>
        
        <p align="left"><a href="<?php echo e(route('data_peminjam.export_excel')); ?>" class="btn btn-primary">Export Data Peminjam</a></p>
        
        <form action="<?php echo e(route('data_peminjam.search')); ?>" method="get"><?php echo csrf_field(); ?>
            <input type="text" name="kata" placeholder="Cari...">
        </form>

        <table class="table table-striped">
            <thread>
                <tr>
                    <th>No</th>
                    <th>Kode Peminjam</th>
                    <th>Nama Peminjam</th>
                    <th>Jenis Kelamin</th>
                    <th>Tanggal Lahir</th>
                    <th>Alamat</th>
                    <th>Pekerjaan</th>
                    <th>Nomor Telepon</th>
                    <th>Foto</th>
                    <th>Edit</th>
                    <th>Hapus</th>
                </tr>
            </thread>
            <tbody>
                <?php $__currentLoopData = $data_peminjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($peminjam->id); ?></td>
                    <td><?php echo e($peminjam->kode_peminjam); ?></td>
                    <td><?php echo e($peminjam->nama_peminjam); ?></td>
                    <td><?php echo e($peminjam->jenis_kelamin['nama_jenis_kelamin']); ?></td>
                    <td><?php echo e($peminjam->tanggal_lahir); ?></td>
                    <td><?php echo e($peminjam->alamat); ?></td>
                    <td><?php echo e($peminjam->pekerjaan); ?></td>
                    <td><?php echo e(!empty($peminjam->telepon['nomor_telepon'])? 
                            $peminjam->telepon['nomor_telepon'] : '-'); ?>

                    </td>
                    <td>
                        <?php if(empty($peminjam->foto)): ?>
                        <img src="<?php echo e(asset('foto_peminjam/foto_peminjam_kosong.png')); ?>" alt="" style="width:50px;height:60px;">
                        <?php else: ?>
                        <img src="<?php echo e(asset('foto_peminjam/'.$peminjam->foto)); ?>" alt="" style="width:50px;height:60px;">
                        <?php endif; ?>
                    </td>
                    <td><a href="<?php echo e(route('data_peminjam.edit', $peminjam->id)); ?>"  class="btn btn-warning btn-sm">Edit</a></td>
                    <td>
                        <form action="<?php echo e(route('data_peminjam.destroy', $peminjam->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-warning btn-sm" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="pull-left">
            <strong>
                Jumlah Peminjam : <?php echo e($jumlah_peminjam); ?>

            </strong>
            <p><?php echo e($data_peminjam->links()); ?> </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/data_peminjam/index.blade.php ENDPATH**/ ?>