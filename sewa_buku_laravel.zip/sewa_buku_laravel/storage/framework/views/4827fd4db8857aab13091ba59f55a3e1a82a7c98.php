
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Data User</h4>
        
        <p align="right"><a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary">Tambah Data User</a></p>
        
        <table class="table table-striped">
            <thread>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th>Edit</th>
                    <th>Hapus</th>
                </tr>
            </thread>
            <tbody>
                <?php $i =0;?>
                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->level); ?></td>
            
                    <td><a href="<?php echo e(route('user.edit', $user->id)); ?>"  class="btn btn-warning btn-sm">Edit</a></td>
                    <td>
                        <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-warning btn-sm" 
                            onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="pull-left">
            <strong>
                Jumlah Peminjam : <?php echo e($jumlah_user); ?>

            </strong>
            <p><?php echo e($user_list->links()); ?> </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/user/index.blade.php ENDPATH**/ ?>