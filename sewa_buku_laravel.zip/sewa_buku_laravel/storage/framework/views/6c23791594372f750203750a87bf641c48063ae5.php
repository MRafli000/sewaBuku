

<?php $__env->startSection('content'); ?>
<div id=peminjam>
    <h3>Data Peminjam</h3>
    <?php if(!empty($peminjam)): ?>
        <ul>
            <?php foreach($peminjam as $data):?>
                <li><?=$data ?></li>
                <?php endforeach ?>
        </ul>
        <?php else: ?>
    <p>Data Peminjam kosong..</p>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\xampp\htdocs\sewa_buku_laravel\resources\views/peminjam/lihat_data_peminjam.blade.php ENDPATH**/ ?>